# #************************************
# import streamlit as st
# import traceback
# from utils import read_file  # Function to read and extract text from the uploaded file
# from extractors import extract_invoice_data, save_llm_response  # Import functions for extraction and saving

# # Streamlit app setup
# st.title("Invoice Data Extractor")

# uploaded_file = st.file_uploader("Upload an Invoice (PDF or TXT)", type=["pdf", "txt"])

# if uploaded_file is not None:
#     try:
#         # Ensure the read_file function correctly reads and extracts text from the file
#         text = read_file(uploaded_file)

#         # Extract the invoice data using the LLM
#         extracted_data = extract_invoice_data(text)

#         if extracted_data:
#             # Display the raw extracted data
#             st.text_area("Raw Extracted Data", value=extracted_data, height=300)

#             # Save the response to the folder
#             filename = uploaded_file.name.split(".")[0]  # Use the filename without extension
#             saved_path = save_llm_response(extracted_data, filename)
#             st.success(f"Extracted data has been saved to: {saved_path}")
#         else:
#             st.error("No data extracted from the invoice.")

#     except Exception as e:
#         traceback.print_exc()  # Print the stack trace for debugging
#         st.error(f"An error occurred while processing the invoice: {e}")
# # *********************************


###########################################

import streamlit as st
import traceback
import json
from utils import read_file  # Function to read and extract text from the uploaded file
from extractors import extract_invoice_data, save_llm_response  # Import functions for extraction and saving
from convert import convert_llm_responses_to_json  # Import the conversion function
from chat import start_chat

# Streamlit app setup
st.title("Invoice Data Extractor")

uploaded_file = st.file_uploader("Upload an Invoice (PDF or TXT)", type=["pdf", "txt"])

if uploaded_file is not None:
    try:
        # Ensure the read_Extracted data harectly reads and extracts text from the file
        text = read_file(uploaded_file)

        # Extract the invoice data using the LLM
        extracted_data = extract_invoice_data(text)

        if extracted_data:
            
            # Save the raw response to the folder
            filename = uploaded_file.name.split(".")[0]  # Use the filename without extension
            saved_path = save_llm_response(extracted_data, filename)
            st.success(f"Extraction coompleted!")

            # Convert the raw LLM responses to JSON files
            convert_llm_responses_to_json()  # Call the function to convert raw responses to JSON

            if extracted_data:
                filename = uploaded_file.name.split(".")[0]
                saved_path = save_llm_response(extracted_data, filename)
                
                # Start the chat functionality, pointing to the invoice_json folder
                start_chat("invoice_json")

        else:
            st.error("No data extracted from the invoice.")

    except Exception as e:
        st.error(f"An error occurred while processing the invoice: {e}")
