# chat.py

import os
import json

def load_invoice_data(invoice_json_folder):
    """
    Load all JSON files from the specified folder and combine the data into a single dictionary.

    :param invoice_json_folder: The folder containing the JSON files
    :return: A dictionary containing all extracted invoice data
    """
    all_data = {}
    for filename in os.listdir(invoice_json_folder):
        if filename.endswith('.json'):
            with open(os.path.join(invoice_json_folder, filename), 'r') as file:
                data = json.load(file)
                all_data.update(data)  # Combine data from multiple files
    return all_data

def start_chat(invoice_json_folder):
    """
    Function to handle user questions about the extracted invoice data.

    :param invoice_json_folder: The folder containing the JSON files
    """
    extracted_data = load_invoice_data(invoice_json_folder)

    print("You can start asking questions about the invoice data. Type 'exit' to stop.")
    
    while True:
        user_question = input("Your question: ")
        
        if user_question.lower() == "exit":
            print("Ending chat. Thank you!")
            break
        
        # Implement logic to find answers based on extracted_data
        answer = answer_question(user_question, extracted_data)
        print(f"Answer: {answer}")

def answer_question(question, extracted_data):
    """
    Function to provide answers based on the extracted data.

    :param question: The user's question
    :param extracted_data: The structured data extracted from the invoices
    :return: The answer to the question
    """
    # Simple keyword search or any other logic to answer questions
    if "customer" in question.lower():
        return extracted_data.get("CustomerInfo", "No customer information found.")
    elif "total" in question.lower():
        return extracted_data.get("InvoiceDetails", {}).get("Total", "No total amount found.")
    # Add more conditions as needed
    return "I'm sorry, I can't answer that question."
